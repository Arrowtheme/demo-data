{
  "last_tab": "",
  "layout": "fullwidth",
  "left-sidebar": "",
  "right-sidebar": "",
  "logo": {
    "url": "<?php echo get_template_directory_uri(); ?>/images/logo.png",
    "id": "",
    "height": "",
    "width": "",
    "thumbnail": ""
  },
  "logo_4": {
    "url": "<?php echo get_template_directory_uri(); ?>/images/logo_4.png",
    "id": "",
    "height": "",
    "width": "",
    "thumbnail": ""
  },
  "logo_5": {
    "url": "<?php echo get_template_directory_uri(); ?>/images/logo_5.png",
    "id": "",
    "height": "",
    "width": "",
    "thumbnail": ""
  },
  "logo_6": {
    "url": "<?php echo get_template_directory_uri(); ?>/images/logo_6.png",
    "id": "",
    "height": "",
    "width": "",
    "thumbnail": ""
  },
  "favicon": {
    "url": "<?php echo get_template_directory_uri(); ?>/images/favicon.ico",
    "id": "",
    "height": "",
    "width": "",
    "thumbnail": ""
  },
  "js-code": "jQuery('.progress-bar-style2').each(function(){\r\n    var percentage = jQuery(this).find('.vc_bar').data('value');\r\n    jQuery(this).find('.vc_bar').css('width',percentage+'%');\r\n})",
  "compile-css": "1",
  "general-bg": {
    "background-color": "#f2f2f2",
    "background-repeat": "no-repeat",
    "background-size": "inherit",
    "background-attachment": "inherit",
    "background-position": "center center",
    "background-image": "",
    "media": {
      "id": "",
      "height": "",
      "width": "",
      "thumbnail": ""
    }
  },
  "general-font": {
    "font-family": "Lato",
    "font-options": "",
    "google": "1",
    "font-weight": "400",
    "font-style": "",
    "font-size": "14px",
    "line-height": "23px",
    "color": "#787878"
  },
  "primary-color": "#FF2759",
  "highlight-color": "#700877",
  "footer-bg-color": "#0C000E",
  "footer-bg": {
    "background-repeat": "no-repeat",
    "background-size": "cover",
    "background-attachment": "inherit",
    "background-position": "center center",
    "background-image": "<?php echo get_template_directory_uri(); ?>/images/bg-footer-v1.jpg",
    "media": {
      "id": "",
      "height": "",
      "width": "",
      "thumbnail": ""
    }
  },
  "breadcrumbs-bg": {
    "background-repeat": "no-repeat",
    "background-size": "cover",
    "background-attachment": "inherit",
    "background-position": "center center",
    "background-image": "https://riven.arrowtheme.com/wp-content/uploads/2019/08/bg-breadcrumb.jpg",
    "media": {
      "id": "1239",
      "height": "200",
      "width": "1920",
      "thumbnail": "https://riven.arrowtheme.com/wp-content/uploads/2019/08/bg-breadcrumb-150x150.jpg"
    }
  },
  "breadcrumbs-bg-5": {
    "background-repeat": "no-repeat",
    "background-size": "cover",
    "background-attachment": "inherit",
    "background-position": "center center",
    "background-image": "<?php echo get_template_directory_uri(); ?>/images/background/breadcrumb_5.jpg",
    "media": {
      "id": "",
      "height": "",
      "width": "",
      "thumbnail": ""
    }
  },
  "h1-font": {
    "font-family": "Lato",
    "font-options": "",
    "google": "1",
    "font-size": "48px",
    "color": "#000000"
  },
  "h2-font": {
    "font-family": "Lato",
    "font-options": "",
    "google": "1",
    "font-size": "36px",
    "color": "#000000"
  },
  "h3-font": {
    "font-family": "Lato",
    "font-options": "",
    "google": "1",
    "font-size": "20px",
    "color": "#000000"
  },
  "h4-font": {
    "font-family": "Lato",
    "font-options": "",
    "google": "1",
    "font-size": "18px",
    "color": "#000000"
  },
  "h5-font": {
    "font-family": "Lato",
    "font-options": "",
    "google": "1",
    "font-size": "16px",
    "color": "#000000"
  },
  "h6-font": {
    "font-family": "Lato",
    "font-options": "",
    "google": "1",
    "font-size": "10px",
    "color": "#000000"
  },
  "custom-css-code": ".woocommerce-MyAccount-navigation li {\r\n display: inline-block;\r\n padding-right: 25px;\r\n}\r\n.woocommerce-MyAccount-navigation {\r\n margin-bottom: 20px;\r\n}\r\n.woocommerce-MyAccount-navigation .is-active a{\r\n      font-weight: bold;\r\n}\t\r\n@media (min-width: 992px) and (max-width:1440px){\r\n    .header-v6 .mega-menu>li a{\r\n    padding: 39px 21px 40px;\r\n}\r\n}\t\t\r\n.single-product.woocommerce h2 span{\r\n    top:4px;\r\n}\r\n.single-product.woocommerce h2 {\r\n    line-height: 28px;\r\n}",
  "header-type": "4",
  "header-link": "#",
  "header-address": "Brooklyn, NY 10036, United States",
  "header-phone-number": "(+84)1234-5678",
  "header-contact-6": "0800 123 456",
  "header-search": "1",
  "header-myaccount": "1",
  "header-cart": "1",
  "header-sticky": "1",
  "logo-header-sticky": {
    "url": "<?php echo get_template_directory_uri(); ?>/images/sticky-logo.png",
    "id": "",
    "height": "",
    "width": "",
    "thumbnail": ""
  },
  "footer-type": "1",
  "footer-copyright": "&copy; Riven 2024. All Rights Reserved. Designed by <a target=\"_blank\" href=\"https://arrowtheme.com/\">ArrowTheme</a>",
  "show-top-footer": "1",
  "show-header-blog": "1",
  "show-slider-blog": "",
  "select-slider-blog": "",
  "post-layout": "fullwidth",
  "left-post-sidebar": "",
  "right-post-sidebar": "blog-sidebar",
  "blog-archive-column": "2",
  "post-banner": "",
  "blog-title": "Blog",
  "event-layout": "fullwidth",
  "left-event-sidebar": "",
  "right-event-sidebar": "event-sidebar",
  "event-title": "Event",
  "portfolio-layout": "wide",
  "left-portfolio-sidebar": "",
  "right-portfolio-sidebar": "",
  "portfolio-banner": "",
  "portfolio-title": "Project",
  "portfolio-single-layout": "fullwidth",
  "shop-layout": "fullwidth",
  "left-shop-sidebar": "shop-sidebar",
  "right-shop-sidebar": "",
  "category-item": "8,16,24",
  "product-cols": "4",
  "product-wishlist": "1",
  "product-compare": "1",
  "single-product-layout": "fullwidth",
  "left-single-product-sidebar": "",
  "right-single-product-sidebar": "single-product-sidebar",
  "social-facebook": "#",
  "social-google": "#",
  "social-twitter": "#",
  "social-linkedin": "#",
  "social-pinterest": "#",
  "social-instagram": "#",
  "social-youtube": "#",
  "redux-backup": 1
}