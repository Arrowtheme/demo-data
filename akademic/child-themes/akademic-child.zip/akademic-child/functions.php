<?php
// push your child theme functions here
function akademic_child_enqueue_style() {
    wp_enqueue_style( 'akademic-child-style', get_stylesheet_directory_uri() . '/style.css');
}
add_action( 'wp_enqueue_scripts', 'akademic_child_enqueue_style', 1000 );
 