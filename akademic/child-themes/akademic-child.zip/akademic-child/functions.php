<?php
// push your child theme functions here
function akademic_child_enqueue_style() {
    wp_enqueue_style( 'akademic-parent-style', get_template_directory_uri() . '/style.css', array(), PHYSC_THEME_VERSION );
}
add_action( 'wp_enqueue_scripts', 'akademic_child_enqueue_style', 1000 );
 