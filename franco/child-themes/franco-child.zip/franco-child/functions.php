<?php
// push your child theme functions here
function franco_child_scripts() {
    wp_enqueue_style( 'franco-parent-style', get_template_directory_uri(). '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'franco_child_scripts' );
