{
   "last_tab":"",
   "layout":"fullwidth",
   "left-sidebar":"",
   "right-sidebar":"",
   "logo":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo.png",
      "id":"",
      "height":"40",
      "width":"",
      "thumbnail":""
   },
   "favicon":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/favicon.ico",
      "id":"",
      "height":"",
      "width":"",
      "thumbnail":""
   },
   "js-code":"jQuery(document).ready(function(){});",
   "compile-css":"0",
   "general-bg":{
      "background-color":"#fff",
      "background-repeat":"no-repeat",
      "background-size":"inherit",
      "background-attachment":"inherit",
      "background-position":"center center",
      "background-image":"",
      "media":{
         "id":"",
         "height":"",
         "width":"",
         "thumbnail":""
      }
   },
   "general-font":{
      "font-family":"Open Sans",
      "font-options":"",
      "google":"1",
      "font-weight":"400",
      "font-style":"",
      "font-size":"14px",
      "line-height":"24px",
      "color":"#010101"
   },
   "primary-color":"#cea35f",
   "highlight-color":"#a1d1dd",
   "header-bg":"transparent",
   "header2-bg":"#161616",
   "header14-bg":"#2a2a2a",
   "header6-bg":"#000000",
   "header6-text":"#ffffff",
   "header9-bg":"#080808",
   "header13-bg":"#ffffff",
   "header13-text":"#000000",
   "header16-top-bg":"#000000",
   "header16-top-text":"#4d4d4d",
   "footer-bg":"#222222",
   "footer3-bg":"#e2e2e2",
   "footer4-bg":"#5c97c3",
   "footer5-bg":"#000000",
   "footer7-bg":"#f0f0f0",
   "footer8-bg":"#ffffff",
   "footer10-bg":"#efefef",
   "footer4-color":"#ffffff",
   "footer3-color":"#424242",
   "footer2-color":"#aaaaaa",
   "footer-color":"#888888",
   "footer-9":"#ffffff",
   "footer10-color":"#aaaaaa",
   "footer10-color-link":"#999999",
   "breadcrumbs-bg":{
      "background-repeat":"no-repeat",
      "background-size":"cover",
      "background-attachment":"inherit",
      "background-position":"center center",
      "background-image":"<?php echo get_template_directory_uri(); ?>/images/bg-breadcrumb.jpg",
      "media":{
         "id":"",
         "height":"",
         "width":"",
         "thumbnail":""
      }
   },
   "breadcrumbs_style":"type-1",
   "h1-font":{
      "font-family":"Montserrat",
      "font-options":"",
      "google":"1",
      "font-size":"36px",
      "color":"#000"
   },
   "h2-font":{
      "font-family":"Montserrat",
      "font-options":"",
      "google":"1",
      "font-size":"36px",
      "color":"#000"
   },
   "h3-font":{
      "font-family":"Montserrat",
      "font-options":"",
      "google":"1",
      "font-size":"24px",
      "color":"#000"
   },
   "h4-font":{
      "font-family":"Montserrat",
      "font-options":"",
      "google":"1",
      "font-size":"16px",
      "color":"#000"
   },
   "h5-font":{
      "font-family":"Montserrat",
      "font-options":"",
      "google":"1",
      "font-size":"14px",
      "color":"#000"
   },
   "h6-font":{
      "font-family":"Montserrat",
      "font-options":"",
      "google":"1",
      "font-size":"12px",
      "color":"#000"
   },
   "custom-css-code":"",
   "header-type":"5",
   "header_text":" Welcome to Franco - an e-Commerce PSD Template!",
   "header_quote":"\u275d A fashion blog is a place where issues such as fashion shows, new trends, fashion brands, designers work, celebrities, or personal style are presented for those passionate about the fashion industry\u275e",
   "logo-header-2":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo_white.png",
      "id":"",
      "height":"60",
      "width":"",
      "thumbnail":""
   },
   "logo3":{
      "url":"http:\/\/demo.arrowpress.net\/franco_sample\/wp-content\/uploads\/2016\/10\/logo3.png",
      "id":"1411",
      "height":"120",
      "width":"120",
      "thumbnail":"http:\/\/demo.arrowpress.net\/franco_sample\/wp-content\/uploads\/2016\/10\/logo3.png"
   },
   "logo_4":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo_black.png",
      "id":"",
      "height":"60",
      "width":"",
      "thumbnail":""
   },
   "logo_10":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo_header10.png",
      "id":"",
      "height":"80",
      "width":"",
      "thumbnail":""
   },
   "logo_13":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo_header13.png",
      "id":"",
      "height":"158",
      "width":"",
      "thumbnail":""
   },
   "logo6":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo6.png",
      "id":"",
      "height":"42",
      "width":"",
      "thumbnail":""
   },
   "logo_8":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo-8.png",
      "id":"",
      "height":"90",
      "width":"",
      "thumbnail":""
   },
   "logo_14":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo-jewelry.png",
      "id":"",
      "height":"46",
      "width":"",
      "thumbnail":""
   },
   "logo_15":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo-decor.png",
      "id":"",
      "height":"165",
      "width":"",
      "thumbnail":""
   },
   "logo_16":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo-handmade.png",
      "id":"",
      "height":"46",
      "width":"",
      "thumbnail":""
   },
   "bg_header_v7":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/bg-header-v7.jpg",
      "id":"",
      "height":"",
      "width":"",
      "thumbnail":""
   },
   "bg_header_v11":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/bg-header-v11.jpg",
      "id":"",
      "height":"",
      "width":"",
      "thumbnail":""
   },
   "header_toplink":"1",
   "header-minicart":"1",
   "header-search":"1",
   "header-shop_setting":"1",
   "header-social":"1",
   "header-sticky":"1",
   "header-sticky-mobile":"1",
   "footer-type":"4",
   "logo-footer-3":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo-footer.png",
      "id":"",
      "height":"60",
      "width":"",
      "thumbnail":""
   },
   "logo_footer_10":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo_footer_10.png",
      "id":"",
      "height":"52",
      "width":"",
      "thumbnail":""
   },
   "footer_slogan":"Aliquam tempor sagittis neque, vel aliquam risus consectetur vel. Aenean hendrerit, elit a lacinia suscipit, orci mauris vulputate mi, eu interdum nunc diam at ipsum.",
   "footer-copyright":"&copy; Copyright 2016 &amp; Made with <i class=\"fa fa-heart\" aria-hidden=\"true\"><\/i> by<a href=\"#\"> ArrowHitech<\/a>",
   "footer2-copyright":"&copy; Copyright 2016 &amp; Made with love by <a href=\"#\"> ArrowHitech<\/a>",
   "show-payment":"1",
   "show-footer-social":"1",
   "link-paypal":"#",
   "link-visa":"#",
   "link-mastercard":"#",
   "link-discover":"#",
   "link-amex":"#",
   "post-layout":"fullwidth",
   "left-post-sidebar":"",
   "right-post-sidebar":"blog-sidebar",
   "blog-title":"Blog",
   "post-layout-version":"list",
   "single-post-layout-version":"single-1",
   "gallery-layout":"fullwidth",
   "left-gallery-sidebar":"",
   "right-gallery-sidebar":"",
   "gallery-cols":"4",
   "gallery-style-version":"1",
   "gallery-loadmore-style":"1",
   "gallery_per_page":"8",
   "product-quickview":"1",
   "product-wishlist":"1",
   "product-compare":"1",
   "product-cart":"1",
   "product-price":"1",
   "product-label":"",
   "shop-layout":"fullwidth",
   "left-shop-sidebar":"",
   "right-shop-sidebar":"",
   "category-item":"12,24,36",
   "product-cols":"4",
   "single-product-layout":"fullwidth",
   "left-single-product-sidebar":"",
   "right-single-product-sidebar":"",
   "single-product-style":"3",
   "product-related":"1",
   "social-twitter":"#",
   "social-linkedin":"#",
   "social-behance":"#",
   "social-dribble":"#",
   "social-facebook":"#",
   "social-instagram":"#",
   "social-pinterset":"#",
   "popup-title":"Join Our Newsletter",
   "popup-description":"Subscribe to the Porto eCommerce newsletter to receive timely updates from your favorite products.",
   "popup-form":"[mc4wp_form id=\"210\"]",
   "404-bg-image":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/background_404.png",
      "id":"",
      "height":"",
      "width":"",
      "thumbnail":""
   },
   "under-contr-mode":"",
   "under-bg-image":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/coming-soon.jpg",
      "id":"",
      "height":"",
      "width":"",
      "thumbnail":""
   },
   "logo-coming":{
      "url":"<?php echo get_template_directory_uri(); ?>/images/logo_black.png",
      "id":"",
      "height":"60",
      "width":"",
      "thumbnail":""
   },
   "under-contr-social":"1",
   "under-contr-title":"under construction",
   "under-contr-content":"<h1>coming soon<\/h1>\r\nAliquam tempus ultricies tincidunt. Donec nunc felis, egestas eu pellentesque a, ultricies non lectus. Phasellus eget aliquet urna. Nullam sit amet turpis ornare, pulvinar lectus in, cursus mi.",
   "under-display-countdown":"1",
   "coming-menu":"68",
   "under-end-date":"03\/30\/2017",
   "under-mail":"1",
   "redux-backup":"1"
}